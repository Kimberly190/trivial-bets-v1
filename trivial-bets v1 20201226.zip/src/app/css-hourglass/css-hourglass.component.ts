import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css-hourglass',
  templateUrl: './css-hourglass.component.html',
  styleUrls: ['./css-hourglass.component.css']
})
export class CssHourglassComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}